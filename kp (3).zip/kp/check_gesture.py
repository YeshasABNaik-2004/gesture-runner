# check_gesture.py
import gesture_detector
print("Loaded from:", gesture_detector.__file__)
print("Exports:", [n for n in dir(gesture_detector) if not n.startswith("_")])
