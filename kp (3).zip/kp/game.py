# game.py
import pygame
import random
import time
import os
from gesture_detector import GestureDetector

class Game:
    def __init__(self, width=600, height=600):
        pygame.init()
        pygame.mixer.init()

        self.width = width
        self.height = height
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Gesture Runner")
        self.clock = pygame.time.Clock()

        assets = lambda fn: os.path.join('assets', fn)

        self.runner_img = pygame.image.load(assets('runner.png')).convert_alpha()
        self.obstacle_img = pygame.image.load(assets('obstacle.png')).convert_alpha()

        pygame.mixer.music.load(assets('music.mp3'))
        pygame.mixer.music.set_volume(0.5)

        self.lanes = [150, 300, 450]
        self.ground_y = 500

        self.detector = None
        self.highscore = 0
        self.state = 'start'

    def reset(self):
        if self.detector:
            self.detector.release()

        self.detector = GestureDetector()

        self.player_lane = 1
        self.player_x = self.lanes[self.player_lane] - self.runner_img.get_width() // 2
        self.player_y = self.ground_y - self.runner_img.get_height()
        self.jumping = False
        self.ducking = False
        self.vel_y = 0
        self.gravity = 0.5

        self.obstacles = []
        self.spawn_interval = 2.0  # minimal usage now, mainly distance based spawn
        self.min_gap = 250  # minimum vertical gap between obstacles (big gap)
        self.score = 0

    def start_screen(self):
        font = pygame.font.SysFont(None, 64)
        small_font = pygame.font.SysFont(None, 36)

        while self.state == 'start':
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    pygame.quit()
                    return
                if e.type == pygame.KEYDOWN and e.key == pygame.K_SPACE:
                    self.reset()
                    self.state = 'playing'
                    pygame.mixer.music.play(-1)

            self.screen.fill((0, 0, 0))
            title = font.render("Gesture Runner", True, (255,255,255))
            prompt = small_font.render("Press SPACE to Start", True, (255,255,255))
            self.screen.blit(title, title.get_rect(center=(self.width/2, self.height/3)))
            self.screen.blit(prompt, prompt.get_rect(center=(self.width/2, self.height/2)))
            pygame.display.flip()
            self.clock.tick(30)

    def game_over_screen(self):
        font = pygame.font.SysFont(None, 64)
        small_font = pygame.font.SysFont(None, 36)

        pygame.mixer.music.stop()

        if self.score > self.highscore:
            self.highscore = self.score

        while self.state == 'gameover':
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    pygame.quit()
                    return
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_r:
                        self.reset()
                        self.state = 'playing'
                        pygame.mixer.music.play(-1)
                    elif e.key == pygame.K_q:
                        pygame.quit()
                        return

            self.screen.fill((0, 0, 0))
            over = font.render("Game Over", True, (255,0,0))
            score_txt = small_font.render(f"Score: {self.score}", True, (255,255,255))
            high_txt = small_font.render(f"Highscore: {self.highscore}", True, (255,255,255))
            prompt = small_font.render("Press R to Replay or Q to Quit", True, (255,255,255))

            self.screen.blit(over, over.get_rect(center=(self.width/2, self.height/3)))
            self.screen.blit(score_txt, score_txt.get_rect(center=(self.width/2, self.height/2)))
            self.screen.blit(high_txt, high_txt.get_rect(center=(self.width/2, self.height/2+40)))
            self.screen.blit(prompt, prompt.get_rect(center=(self.width/2, self.height/2+100)))
            pygame.display.flip()
            self.clock.tick(30)

    def run(self):
        self.start_screen()

        while True:
            if self.state != 'playing':
                self.state = 'gameover'
                self.game_over_screen()
                break

            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    pygame.quit()
                    return

            horiz, vert = self.detector.process_frame()

            # Backup keyboard controls
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                horiz = "Left"
            elif keys[pygame.K_RIGHT]:
                horiz = "Right"
            if keys[pygame.K_UP]:
                vert = "Jump"
            elif keys[pygame.K_DOWN]:
                vert = "Duck"

            # Player Movement
            if horiz == "Left":
                self.player_lane = max(self.player_lane - 1, 0)
            elif horiz == "Right":
                self.player_lane = min(self.player_lane + 1, 2)
            self.player_x = self.lanes[self.player_lane] - self.runner_img.get_width() // 2

            if vert == "Jump" and not self.jumping:
                self.jumping = True
                self.vel_y = -12
            self.ducking = (vert == "Duck") and not self.jumping

            if self.jumping:
                self.vel_y += self.gravity
                self.player_y += self.vel_y
                if self.player_y >= self.ground_y - self.runner_img.get_height():
                    self.player_y = self.ground_y - self.runner_img.get_height()
                    self.jumping = False
                    self.vel_y = 0

            # Spawn new obstacle if enough distance
            can_spawn = False
            if not self.obstacles:
                can_spawn = True
            else:
                last_obs = self.obstacles[-1]
                if last_obs.y > self.min_gap:
                    can_spawn = True

            if can_spawn:
                lane = random.randint(0, 2)
                x = self.lanes[lane] - self.obstacle_img.get_width() // 2
                rect = pygame.Rect(x, -self.obstacle_img.get_height(), self.obstacle_img.get_width(), self.obstacle_img.get_height())
                self.obstacles.append(rect)

            # Move obstacles
            for obs in self.obstacles[:]:
                obs.y += 7  # Fast fall
                if obs.top > self.height:
                    self.obstacles.remove(obs)
                    self.score += 1
                else:
                    ph = self.runner_img.get_height()//2 if self.ducking else self.runner_img.get_height()
                    py = self.ground_y - ph
                    player_rect = pygame.Rect(self.player_x, py, self.runner_img.get_width(), ph)
                    if player_rect.colliderect(obs):
                        self.state = 'gameover'

            # Draw everything
            self.screen.fill((0, 0, 0))

            for obs in self.obstacles:
                self.screen.blit(self.obstacle_img, obs.topleft)

            ph = self.runner_img.get_height()//2 if self.ducking else self.runner_img.get_height()
            py = self.ground_y - ph
            self.screen.blit(self.runner_img, (self.player_x, py))

            font = pygame.font.SysFont(None, 32)
            score_surf = font.render(f"Score: {self.score}", True, (255,255,255))
            self.screen.blit(score_surf, (10, 10))

            pygame.display.flip()
            self.clock.tick(30)

        if self.detector:
            self.detector.release()

        pygame.quit()

if __name__ == '__main__':
    Game().run()
