import cv2
import mediapipe as mp
from collections import deque

class GestureDetector:
    def __init__(self, cam_index=0, vote_frames=3):
        self.cap = cv2.VideoCapture(cam_index)
        mp_pose = mp.solutions.pose
        self.pose = mp_pose.Pose(
            static_image_mode=False,
            model_complexity=1,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )

        self.base_shoulder_y = None
        self.calib_frames = 30
        self.calib_count = 0
        self.calib_sum = 0

        self.horiz_buf = deque(maxlen=vote_frames)
        self.vert_buf = deque(maxlen=vote_frames)

    def process_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return None, None

        frame = cv2.flip(frame, 1)
        h, w = frame.shape[:2]
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = self.pose.process(rgb)

        horiz, vert = None, None

        if res.pose_landmarks:
            lm = res.pose_landmarks.landmark

            ls_y = lm[mp.solutions.pose.PoseLandmark.LEFT_SHOULDER].y * h
            rs_y = lm[mp.solutions.pose.PoseLandmark.RIGHT_SHOULDER].y * h
            lw_y = lm[mp.solutions.pose.PoseLandmark.LEFT_WRIST].y * h
            rw_y = lm[mp.solutions.pose.PoseLandmark.RIGHT_WRIST].y * h

            mid_sh = (ls_y + rs_y) / 2

            if self.calib_count < self.calib_frames:
                self.calib_sum += mid_sh
                self.calib_count += 1
                if self.calib_count == self.calib_frames:
                    self.base_shoulder_y = self.calib_sum / self.calib_frames
            else:
                thresh = 0.05 * h  # MUCH smaller threshold (5%)
                
                if lw_y < ls_y - thresh and rw_y < rs_y - thresh:
                    vert = "Jump"
                elif mid_sh > self.base_shoulder_y + thresh:
                    vert = "Duck"
                elif lw_y < ls_y - thresh:
                    horiz = "Left"
                elif rw_y < rs_y - thresh:
                    horiz = "Right"

        # Voting system
        if horiz:
            self.horiz_buf.append(horiz)
        if vert:
            self.vert_buf.append(vert)

        horiz_final = None
        vert_final = None

        if len(self.horiz_buf) == self.horiz_buf.maxlen:
            most = max(set(self.horiz_buf), key=self.horiz_buf.count)
            if self.horiz_buf.count(most) >= 2:
                horiz_final = most
            self.horiz_buf.clear()

        if len(self.vert_buf) == self.vert_buf.maxlen:
            most = max(set(self.vert_buf), key=self.vert_buf.count)
            if self.vert_buf.count(most) >= 2:
                vert_final = most
            self.vert_buf.clear()

        # Show preview window
        small_frame = cv2.resize(frame, (320, 240))
        cv2.imshow("Gesture Preview", small_frame)
        if cv2.waitKey(1) == 27:  # ESC key
            self.release()

        return horiz_final, vert_final

    def release(self):
        self.cap.release()
        cv2.destroyAllWindows()
