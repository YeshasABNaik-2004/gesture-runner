# main.py
from game import Game
print(">> LAUNCHING RUNNER <<")


if __name__ == "__main__":
    game = Game()
    game.run()
